package com.eighteengray.procameralibrary.dataevent;

public class ImageFolderEvent
{
    private int currentImageFolderNum;

    public int getCurrentImageFolderNum()
    {
        return currentImageFolderNum;
    }

    public void setCurrentImageFolderNum(int currentImageFolderNum)
    {
        this.currentImageFolderNum = currentImageFolderNum;
    }
}
