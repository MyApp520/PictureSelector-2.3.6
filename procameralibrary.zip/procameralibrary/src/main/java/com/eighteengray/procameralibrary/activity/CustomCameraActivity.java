package com.eighteengray.procameralibrary.activity;

import android.hardware.camera2.CameraAccessException;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.eighteengray.procameralibrary.R;
import com.eighteengray.procameralibrary.camera.Camera2TextureView;
import com.eighteengray.procameralibrary.camera.TextureViewTouchEvent;
import com.eighteengray.procameralibrary.common.Constants;
import com.eighteengray.procameralibrary.dataevent.ImageAvailableEvent;
import com.eighteengray.procameralibrary.fragment.FullScreenDialogFragment;
import com.eighteengray.procameralibrary.widget.FocusView;
import com.eighteengray.procameralibrary.widget.ImageSaver;
import com.eighteengray.procameralibrary.widget.TextureViewTouchListener;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class CustomCameraActivity extends FragmentActivity {

    private final String TAG = getClass().getSimpleName();

    private Camera2TextureView cameraTextureView;
    private FocusView mFocusView;

    private TextureViewTouchListener textureViewTouchListener;
    private ImageView ivTakePicture;

    private float mRawX, mRawY; //触摸聚焦时候的中心点

    /**
     * 聚焦图像是否显示的标志位
     */
    private boolean mFlagShowFocusImage = false;

    private FullScreenDialogFragment mFullScreenDialogFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_camera);
        EventBus.getDefault().register(this);

        cameraTextureView = findViewById(R.id.cameraTextureView);
        ivTakePicture = findViewById(R.id.iv_take_picture);
        mFocusView = findViewById(R.id.focusview_camera2);

        setIvTakePictureOnClickListener();
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.e(TAG, "onResume: ");
        openCamera();
    }

    @Override
    public void onPause() {
        Log.e(TAG, "onPause: ");
        closeCamera();
        super.onPause();
    }

    private void setIvTakePictureOnClickListener() {
        ivTakePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 点击拍照
                cameraTextureView.takePicture();
            }
        });
    }

    private void openCamera() {
        if (cameraTextureView != null) {
            cameraTextureView.openCamera();
            textureViewTouchListener = new TextureViewTouchListener(cameraTextureView);
            cameraTextureView.setOnTouchListener(textureViewTouchListener);
        }
    }

    private void closeCamera() {
        if (cameraTextureView != null) {
            cameraTextureView.closeCamera();
            textureViewTouchListener = null;
            cameraTextureView.setOnTouchListener(null);
        }
    }

    //EventBus--TextureView触摸事件
    @Subscribe(threadMode = ThreadMode.MAIN)  //轻按：显示焦点，完成聚焦和测光。
    public void onTextureClick(TextureViewTouchEvent.TextureClick textureClick) throws CameraAccessException {
        mRawX = textureClick.getRawX();
        mRawY = textureClick.getRawY();
        cameraTextureView.focusRegion(textureClick.getX(), textureClick.getY());
    }

    @Subscribe(threadMode = ThreadMode.MAIN) // 单指滑动，如果是向右下则进度环增加，否则减小，用于调节焦点白平衡。
    public void onTextureOneDrag(TextureViewTouchEvent.TextureOneDrag textureOneDrag) {
        mFocusView.dragChangeAWB(textureOneDrag.getDistance());
    }


    //聚焦的四种状态，对应的显示的View
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onShowFocus(TextureViewTouchEvent.FocusState focusState) {
        switch (focusState.getFocusState()) {
            case Constants.FOCUS_FOCUSING:
                if (mFlagShowFocusImage == false) {
                    //聚焦图片显示在手点击的位置
                    if (mRawX == 0 || mRawY == 0) {
                        mRawX = cameraTextureView.getMeasuredWidth() / 2;
                        mRawY = cameraTextureView.getMeasuredHeight() / 2;
                    }
                    mFocusView.showFocusing(mRawX, mRawY, textureViewTouchListener);
                    mFlagShowFocusImage = true;
                }
                break;

            case Constants.FOCUS_SUCCEED:
                if (mFlagShowFocusImage == true) {
                    mFocusView.showFocusSucceed(textureViewTouchListener);
                    mFlagShowFocusImage = false;
                }
                break;

            case Constants.FOCUS_INACTIVE:
                mFocusView.setVisibility(View.GONE);
                mFlagShowFocusImage = false;
                break;

            case Constants.FOCUS_FAILED:
                if (mFlagShowFocusImage == true) {
                    mFocusView.showFocusFailed();
                    mFlagShowFocusImage = false;
                }
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN) //拍照完成后，拿到ImageReader，然后做保存图片的操作
    public void onImageReaderAvailable(ImageAvailableEvent.ImageReaderAvailable imageReaderAvailable) {
        new Thread(new ImageSaver(imageReaderAvailable.getImageReader(), getApplicationContext())).start();
    }

    @Subscribe(threadMode = ThreadMode.MAIN) //存储图像完成后，拿到ImagePath图片路径
    public void onImagePathAvailable(ImageAvailableEvent.ImagePathAvailable imagePathAvailable) {
        showFullScreenDialogFragment(imagePathAvailable.getImagePath());
    }

    private void showFullScreenDialogFragment(String imagePath) {
        Log.e(TAG, "onImagePathAvailable: imagePath = " + imagePath);
        mFullScreenDialogFragment = FullScreenDialogFragment.newInstance(imagePath);
        mFullScreenDialogFragment.show(getSupportFragmentManager(), FullScreenDialogFragment.class.getSimpleName());
    }

    public void needFinish() {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
        try {
            cameraTextureView.unlockFocus();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (mFullScreenDialogFragment != null) {
            mFullScreenDialogFragment.dismiss();
        }
    }
}
