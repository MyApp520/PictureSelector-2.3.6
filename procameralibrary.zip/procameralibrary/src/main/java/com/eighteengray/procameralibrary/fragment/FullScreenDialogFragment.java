package com.eighteengray.procameralibrary.fragment;


import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

import com.eighteengray.procameralibrary.R;
import com.eighteengray.procameralibrary.activity.CustomCameraActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class FullScreenDialogFragment extends DialogFragment implements View.OnClickListener {

    private final String TAG = getClass().getSimpleName();

    private CustomCameraActivity mCustomCameraActivity;

    /**
     * 设置图片路径
     */
    private String pictureFilePath;

    private ImageView mImageView;
    private Button btn_cancel, btn_manual_select_face, btn_auto_select_face;

    public static FullScreenDialogFragment newInstance(String pictureFilePath) {
        // Required empty public constructor
        FullScreenDialogFragment fullScreenDialogFragment = new FullScreenDialogFragment();
        Bundle bundle = new Bundle();
        bundle.putString("pictureFilePath", pictureFilePath);
        fullScreenDialogFragment.setArguments(bundle);
        return fullScreenDialogFragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mCustomCameraActivity = (CustomCameraActivity) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_full_screen_dialog, container, false);

        mImageView = rootView.findViewById(R.id.image_view);
        btn_cancel = rootView.findViewById(R.id.btn_cancel);
        btn_manual_select_face = rootView.findViewById(R.id.btn_manual_select_face);
        btn_auto_select_face = rootView.findViewById(R.id.btn_auto_select_face);

        btn_cancel.setOnClickListener(FullScreenDialogFragment.this);
        btn_manual_select_face.setOnClickListener(FullScreenDialogFragment.this);
        btn_auto_select_face.setOnClickListener(FullScreenDialogFragment.this);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        super.onActivityCreated(savedInstanceState);
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(0x00000000));
        getDialog().getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);

        if (getArguments() != null) {
            pictureFilePath = getArguments().getString("pictureFilePath", "");
            setPictureFilePath(pictureFilePath);
        }
    }

    /**
     * 设置图片路径
     *
     * @param pictureFilePath
     */
    private void setPictureFilePath(String pictureFilePath) {
        try {
            mImageView.setImageBitmap(BitmapFactory.decodeFile(pictureFilePath));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        if (R.id.btn_cancel == viewId) {
            dismiss();
        } else if (R.id.btn_manual_select_face == viewId) {
            mCustomCameraActivity.needFinish();
        } else if (R.id.btn_auto_select_face == viewId) {
            mCustomCameraActivity.needFinish();
        }
    }
}
