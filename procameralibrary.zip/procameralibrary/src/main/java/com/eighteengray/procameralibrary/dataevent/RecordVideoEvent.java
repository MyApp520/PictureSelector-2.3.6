package com.eighteengray.procameralibrary.dataevent;



public class RecordVideoEvent
{
    private boolean isRecording;

    public boolean isRecording()
    {
        return isRecording;
    }

    public void setRecording(boolean recording)
    {
        isRecording = recording;
    }

}
