package com.eighteengray.procameralibrary.dataevent;



public class ModeSelectEvent
{

    private int mode;

    public int getMode()
    {
        return mode;
    }

    public void setMode(int mode)
    {
        this.mode = mode;
    }

}
